if(window.location.href.indexOf("fullcpgrid") == -1) {
   console.log("ok");
   document.body.innerHTML += '<iframe src="https://codepen.io/z-/posts/popular/" frameborder="0" width="72" height="20" style="position:absolute; top:9px; right:8px; z-index:1000;"></iframe>';
   /*]document.head.innerHTML += '<link rel="stylesheet" type="text/css" href="https://codepen.io/z-/pen/a8e37caf2a04602ea5815e5acedab458.css">'
   document.body.innerHTML += '<iframe src="https://codepen.io/z-/" frameborder="0" width="72" height="20" style="position:absolute; top:9px; right:8px"></iframe>';*/
}

//fullcpgrid/a8e37caf2a04602ea5815e5acedab458
;
